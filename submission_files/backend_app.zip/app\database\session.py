import os
from sqlalchemy.ext.asyncio import create_async_engine, AsyncSession, async_sessionmaker
from sqlalchemy.orm import declarative_base, sessionmaker
from sqlalchemy import create_engine
from app.core.config import settings

# Async Engine (for FastAPI async request handlers)
async_engine = create_async_engine(
    settings.DATABASE_URL,
    echo=False,
    future=True
)

AsyncSessionLocal = async_sessionmaker(
    bind=async_engine,
    class_=AsyncSession,
    expire_on_commit=False,
    autocommit=False,
    autoflush=False
)

# Sync Engine (for initial seed data and background calculations)
sync_engine = create_engine(
    settings.SYNC_DATABASE_URL,
    echo=False,
    future=True,
    connect_args={"check_same_thread": False} if "sqlite" in settings.SYNC_DATABASE_URL else {}
)

SyncSessionLocal = sessionmaker(
    bind=sync_engine,
    autocommit=False,
    autoflush=False
)

Base = declarative_base()

def ensure_sqlite_schema():
    """Ensures dataset_id column exists on existing SQLite tables without losing data."""
    if "sqlite" not in settings.SYNC_DATABASE_URL:
        return
    import sqlite3
    db_path = settings.SYNC_DATABASE_URL.replace("sqlite:///", "")
    if not os.path.exists(db_path):
        return
    try:
        con = sqlite3.connect(db_path)
        cur = con.cursor()
        tables_to_check = [
            "assets", "vulnerabilities", "threat_indicators", "risk_assessments",
            "optimization_runs", "ciso_decisions", "audit_logs", "risk_scenarios",
            "security_incidents"
        ]
        for tbl in tables_to_check:
            table_exists = cur.execute(f"SELECT name FROM sqlite_master WHERE type='table' AND name='{tbl}'").fetchone()
            if table_exists:
                cols = [c[1] for c in cur.execute(f"PRAGMA table_info({tbl})").fetchall()]
                if "dataset_id" not in cols:
                    cur.execute(f"ALTER TABLE {tbl} ADD COLUMN dataset_id VARCHAR(100) DEFAULT 'sih_ps26105'")
        con.commit()
        con.close()
    except Exception:
        pass


async def get_db():
    async with AsyncSessionLocal() as session:
        try:
            yield session
        finally:
            await session.close()

def get_sync_db():
    db = SyncSessionLocal()
    try:
        yield db
    finally:
        db.close()
