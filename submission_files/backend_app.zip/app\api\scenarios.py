"""
Digital Twin & What-If Scenario Analysis API Router.
Enables CISO and risk teams to simulate security investments, control failures,
and adversary campaigns without modifying the baseline operational environment.
Always marks outputs as SIMULATED SCENARIO.
"""

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from pydantic import BaseModel
from typing import Dict, Any, Optional, List
from datetime import datetime

from app.database.session import get_sync_db
from app.database.models import RiskAssessment, Asset, SecurityControl, ScenarioRecord
from app.api.auth import get_current_user
from app.optimization_engine.solver import optimizer
from app.scenarios.what_if_engine import get_available_interventions, calculate_what_if_scenario

router = APIRouter(prefix="/scenarios", tags=["Digital Twin & What-If Simulator"])

class ControlInterventionRequest(BaseModel):
    intervention_id: str
    custom_investment_cost: Optional[float] = None
    custom_baseline_criticality: Optional[float] = None

@router.get("/interventions")
def list_interventions():
    """Returns the list of 7 enterprise security interventions for What-If simulation."""
    return get_available_interventions()

@router.post("/simulate-control")
def simulate_control_intervention(
    request: ControlInterventionRequest,
    current_user = Depends(get_current_user),
    db: Session = Depends(get_sync_db)
):
    """
    Executes a real Before -> Control -> After calculation using the centralized FAIR risk engine.
    """
    custom_baseline = None
    if request.custom_baseline_criticality:
        custom_baseline = {"asset_criticality": request.custom_baseline_criticality}

    try:
        result = calculate_what_if_scenario(
            intervention_id=request.intervention_id,
            custom_cost=request.custom_investment_cost,
            custom_baseline=custom_baseline
        )
        latest_assessment = db.query(RiskAssessment).filter(
            RiskAssessment.organization_id == current_user.organization_id
        ).order_by(RiskAssessment.timestamp.desc()).first()
        result["timestamp"] = latest_assessment.timestamp.isoformat() if latest_assessment else datetime.utcnow().isoformat()
        return result
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))


class WhatIfSimulationRequest(BaseModel):
    name: Optional[str] = "Interactive What-If Simulation"
    mfa_coverage: Optional[float] = 72.0          # 0-100%
    edr_coverage: Optional[float] = 85.0          # 0-100%
    patch_cadence_score: Optional[float] = 70.0   # 0-100%
    network_segmentation: Optional[float] = 60.0  # 0-100%
    threat_likelihood_mod: Optional[float] = 1.0  # 0.5x to 2.0x
    custom_spend_mfa: Optional[float] = None      # e.g. ₹20 Lakh
    log4j_exploited: Optional[bool] = None        # True/False
    control_effectiveness_boost: Optional[float] = None # e.g. +20%
    budget_cap: Optional[float] = None            # e.g. ₹50 Lakh
    asset_internet_exposed_target: Optional[str] = None # asset ID/name

from app.risk_engine.fair_model import run_fair_analysis
from app.risk_engine.likelihood import calculate_loss_event_frequency

@router.post("/simulate")
@router.post("/what-if")
def simulate_what_if(
    request: WhatIfSimulationRequest,
    current_user = Depends(get_current_user),
    db: Session = Depends(get_sync_db)
):
    """
    Simulates digital twin control adjustments through the centralized FAIR risk engine:
        Current (LEF, SLE, EAL) -> Apply Proposed Controls -> New (LEF, SLE, EAL) -> Modeled Risk Reduction
    """
    latest_assessment = db.query(RiskAssessment).filter(
        RiskAssessment.organization_id == current_user.organization_id
    ).order_by(RiskAssessment.timestamp.desc()).first()
    baseline_risk = latest_assessment.expected_annual_loss if latest_assessment else 46000000.0

    # 1. Baseline control parameters
    base_mfa = 72.0
    base_edr = 85.0
    base_patch = 70.0
    base_seg = 60.0
    base_avg_cov = (base_mfa + base_edr + base_patch + base_seg) / 4.0  # 71.75%
    base_avg_eff = 75.0

    # 2. Simulated control adjustments
    mfa_cov = request.mfa_coverage if request.mfa_coverage is not None else base_mfa
    edr_cov = request.edr_coverage if request.edr_coverage is not None else base_edr
    patch_cov = request.patch_cadence_score if request.patch_cadence_score is not None else base_patch
    seg_cov = request.network_segmentation if request.network_segmentation is not None else base_seg

    investment_cost = 0.0
    if request.custom_spend_mfa:
        investment_cost = request.custom_spend_mfa
        # ₹20 Lakh investment raises MFA coverage from 72% to ~98%
        mfa_cov = min(100.0, base_mfa + (request.custom_spend_mfa / 1000000.0) * 13.0)

    if request.control_effectiveness_boost:
        mfa_cov = min(100.0, mfa_cov + request.control_effectiveness_boost)
        edr_cov = min(100.0, edr_cov + request.control_effectiveness_boost)
        patch_cov = min(100.0, patch_cov + request.control_effectiveness_boost)
        seg_cov = min(100.0, seg_cov + request.control_effectiveness_boost)

    sim_avg_cov = (mfa_cov + edr_cov + patch_cov + seg_cov) / 4.0
    sim_avg_eff = min(95.0, base_avg_eff + (sim_avg_cov - base_avg_cov) * 0.4)

    # 3. Threat and exploit conditions
    has_active_exploit = True if request.log4j_exploited is not False else False
    is_internet_exposed = True if (request.asset_internet_exposed_target or True) else False
    threat_mod = request.threat_likelihood_mod or 1.0

    # Baseline FAIR calculation
    baseline_fair = run_fair_analysis(
        asset_criticality=92.0,
        threat_activity=85.0 * threat_mod,
        cvss_score=9.8 if has_active_exploit else 7.0,
        active_exploitation=has_active_exploit,
        is_internet_exposed=is_internet_exposed,
        control_coverage=base_avg_cov,
        control_effectiveness=base_avg_eff,
        in_attack_path=True
    )

    # Simulated FAIR calculation with proposed controls applied
    simulated_fair = run_fair_analysis(
        asset_criticality=92.0,
        threat_activity=85.0 * threat_mod,
        cvss_score=9.8 if has_active_exploit else 7.0,
        active_exploitation=has_active_exploit,
        is_internet_exposed=is_internet_exposed,
        control_coverage=sim_avg_cov,
        control_effectiveness=sim_avg_eff,
        in_attack_path=True if seg_cov < 80.0 else False  # Segmentation breaks lateral attack path!
    )

    # Modeled Enterprise-wide proportional effect
    base_lef = baseline_fair["loss_event_frequency"]
    sim_lef = simulated_fair["loss_event_frequency"]
    reduction_ratio = max(-1.0, min(0.95, (base_lef - sim_lef) / max(0.01, base_lef)))

    simulated_risk = max(1000000.0, round(baseline_risk * (1.0 - reduction_ratio), 2))
    net_risk_reduction = round(baseline_risk - simulated_risk, 2)

    # Persist scenario record
    scenario = ScenarioRecord(
        organization_id=current_user.organization_id,
        name=request.name or "Interactive What-If Scenario",
        description=f"Simulated parameters: MFA {mfa_cov:.1f}%, EDR {edr_cov:.1f}%, Patch {patch_cov:.1f}%, Seg {seg_cov:.1f}%.",
        parameters=request.model_dump(exclude_unset=True) if hasattr(request, "model_dump") else request.dict(exclude_unset=True),
        baseline_risk=baseline_risk,
        simulated_risk=round(simulated_risk, 2),
        modeled_risk_reduction=round(net_risk_reduction, 2)
    )
    db.add(scenario)
    db.commit()
    db.refresh(scenario)

    return {
        "scenario_id": scenario.id,
        "name": scenario.name,
        "baseline_modeled_risk": baseline_risk,
        "baseline_label": f"₹{round(baseline_risk/10000000, 2)} Cr",
        "current_likelihood_frequency": base_lef,
        "current_single_loss_expectancy": baseline_fair["single_loss_expectancy"],
        "simulated_modeled_risk": round(simulated_risk, 2),
        "simulated_label": f"₹{round(simulated_risk/10000000, 2)} Cr" if simulated_risk >= 10000000 else f"₹{round(simulated_risk/100000, 1)} L",
        "new_likelihood_frequency": sim_lef,
        "new_single_loss_expectancy": simulated_fair["single_loss_expectancy"],
        "modeled_risk_reduction": round(net_risk_reduction, 2),
        "modeled_reduction_label": f"{'+' if net_risk_reduction >= 0 else ''}₹{round(net_risk_reduction/100000, 1)} L",
        "investment_cost": investment_cost,
        "investment_cost_label": f"₹{round(investment_cost/100000, 1)} Lakh" if investment_cost > 0 else "N/A",
        "simulated_parameters": request.model_dump(exclude_unset=True) if hasattr(request, "model_dump") else request.dict(exclude_unset=True),
        "modeled_label": "SIMULATED SCENARIO",
        "disclaimer": "Digital twin simulations evaluate control adjustments using the centralized FAIR quantitative cyber risk engine."
    }


@router.get("")
def list_scenarios(
    current_user = Depends(get_current_user),
    db: Session = Depends(get_sync_db)
):
    scenarios = db.query(ScenarioRecord).filter(
        ScenarioRecord.organization_id == current_user.organization_id
    ).order_by(ScenarioRecord.created_at.desc()).limit(20).all()
    return scenarios

@router.get("/digital-twin")
def get_digital_twin_state(
    current_user = Depends(get_current_user),
    db: Session = Depends(get_sync_db)
):
    asset_count = db.query(Asset).filter(Asset.organization_id == current_user.organization_id).count()
    controls = db.query(SecurityControl).filter(SecurityControl.organization_id == current_user.organization_id).all()

    return {
        "entity_name": "ABC Bank Virtual Digital Twin",
        "simulated_assets_count": asset_count,
        "active_controls": [
            {
                "code": c.code,
                "name": c.name,
                "coverage": c.coverage_percentage,
                "effectiveness": c.effectiveness_percentage
            }
            for c in controls
        ],
        "twin_status": "SYNCHRONIZED_WITH_TELEMETRY"
    }

@router.get("/{scenario_id}")
def get_scenario(
    scenario_id: str,
    current_user = Depends(get_current_user),
    db: Session = Depends(get_sync_db)
):
    sc = db.query(ScenarioRecord).filter(
        ScenarioRecord.id == scenario_id,
        ScenarioRecord.organization_id == current_user.organization_id
    ).first()
    if not sc:
        raise HTTPException(status_code=404, detail="Scenario record not found")
    return sc
