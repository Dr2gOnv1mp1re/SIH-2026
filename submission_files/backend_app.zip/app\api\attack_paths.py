from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from app.database.session import get_sync_db
from app.api.auth import get_current_user
from app.attack_paths.analyzer import attack_path_engine

router = APIRouter(prefix="/attack-paths", tags=["Attack Path Analysis & Graph Visualizer"])

@router.get("")
def get_attack_paths(current_user = Depends(get_current_user), db: Session = Depends(get_sync_db)):
    data = attack_path_engine.get_attack_graph_data()
    return data

@router.get("/{path_id}")
def get_attack_path_detail(path_id: str, current_user = Depends(get_current_user), db: Session = Depends(get_sync_db)):
    data = attack_path_engine.get_attack_graph_data()
    for p in data["critical_attack_paths"]:
        if p["id"] == path_id:
            return p
    return data["critical_attack_paths"][0]
