from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from pydantic import BaseModel
from typing import List, Optional
from app.database.session import get_sync_db
from app.database.models import Threat, ThreatIndicator
from app.api.auth import get_current_user

router = APIRouter(prefix="/threats", tags=["Threat Intelligence"])

class ThreatCreateRequest(BaseModel):
    threat_actor: str
    threat_type: str = "Ransomware & Extortion"
    attack_technique: str = "T1190 - Exploit Public-Facing App"
    threat_severity: str = "CRITICAL"
    active_campaign: bool = True
    exploit_cves: Optional[List[str]] = []
    target_asset_types: Optional[List[str]] = []
    relevance_score: float = 90.0

@router.get("")
def list_threats(current_user = Depends(get_current_user), db: Session = Depends(get_sync_db)):
    threats = db.query(Threat).filter(Threat.organization_id == current_user.organization_id).order_by(Threat.relevance_score.desc()).all()
    return threats

@router.post("")
def create_threat(request: ThreatCreateRequest, current_user = Depends(get_current_user), db: Session = Depends(get_sync_db)):
    threat = Threat(
        organization_id=current_user.organization_id,
        threat_actor=request.threat_actor,
        threat_type=request.threat_type,
        attack_technique=request.attack_technique,
        threat_severity=request.threat_severity,
        active_campaign=request.active_campaign,
        exploit_cves=request.exploit_cves or [],
        target_asset_types=request.target_asset_types or [],
        relevance_score=request.relevance_score
    )
    db.add(threat)
    db.commit()
    db.refresh(threat)
    return threat

