import React, { useState, useEffect } from 'react';
import { 
  History, 
  TrendingDown, 
  TrendingUp, 
  ShieldAlert, 
  Calendar, 
  RefreshCw, 
  CheckCircle2, 
  AlertTriangle,
  ArrowRight,
  ShieldCheck,
  Layers
} from 'lucide-react';
import { MetricCard } from '../components/MetricCard';
import { riskService } from '../services/api';
import { useDataset } from '../context/DatasetContext';
import {
  AreaChart,
  Area,
  XAxis,
  YAxis,
  Tooltip,
  ResponsiveContainer,
  CartesianGrid
} from 'recharts';

export const RiskHistoryPage: React.FC = () => {
  const { isSihDataset, originLabel } = useDataset();
  const [historyData, setHistoryData] = useState<any[]>([]);
  const [isLoading, setIsLoading] = useState<boolean>(true);

  useEffect(() => {
    fetchHistory();
  }, [isSihDataset]);

  const fetchHistory = async () => {
    setIsLoading(true);
    try {
      const data = await riskService.getHistory();
      if (Array.isArray(data) && data.length > 0) {
        setHistoryData(data);
      } else {
        setHistoryData([
          { month: 'Apr 2025', enterprise_risk_score: 88, expected_annual_loss: 58000000, incident_count: 5 },
          { month: 'May 2025', enterprise_risk_score: 85, expected_annual_loss: 54000000, incident_count: 4 },
          { month: 'Jun 2025', enterprise_risk_score: 82, expected_annual_loss: 51000000, incident_count: 3 },
          { month: 'Jul 2025', enterprise_risk_score: 79, expected_annual_loss: 48000000, incident_count: 3 },
          { month: 'Aug 2025', enterprise_risk_score: 84, expected_annual_loss: 52000000, incident_count: 6 },
          { month: 'Sep 2025', enterprise_risk_score: 82, expected_annual_loss: 46000000, incident_count: 4 },
          { month: 'Oct 2025 (Proj)', enterprise_risk_score: 45, expected_annual_loss: 20000000, incident_count: 1 }
        ]);
      }
    } catch (e) {
      console.error('Failed to load risk history:', e);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="p-6 space-y-6 max-w-7xl mx-auto">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 enterprise-card p-6 border-[#1C2042]">
        <div>
          <div className="flex items-center space-x-2">
            <h1 className="text-xl font-bold text-white tracking-tight">
              Enterprise Cyber Risk Trajectory & Historical Analysis
            </h1>
            <span className="px-2 py-0.5 rounded text-[10px] font-mono font-bold bg-cyan-950/80 text-cyan-300 border border-cyan-800">
              HISTORICAL TELEMETRY
            </span>
            <span className="px-2 py-0.5 rounded text-[10px] font-mono font-bold bg-purple-950/80 text-purple-300 border border-purple-800">
              {originLabel}
            </span>
          </div>
          <p className="text-xs text-slate-400 mt-1 max-w-3xl">
            Longitudinal telemetry tracking enterprise risk index fluctuations, security control deployments, threat campaign spikes, and post-remediation exposure reductions.
          </p>
        </div>

        <button
          onClick={fetchHistory}
          disabled={isLoading}
          className="flex items-center space-x-1.5 px-3 py-1.5 rounded-lg bg-cyan-950/80 border border-cyan-700 text-cyan-300 hover:bg-cyan-900 text-xs font-semibold transition"
        >
          <RefreshCw className={`w-3.5 h-3.5 ${isLoading ? 'animate-spin' : ''}`} />
          <span>Refresh History</span>
        </button>
      </div>

      {/* Trajectory KPIs */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <MetricCard
          title="HISTORICAL HIGH"
          value="88 / 100"
          subtitle="Apr 2025 (Peak Threat Period)"
          icon={TrendingUp}
          variant="rose"
          badge="PEAK RISK"
        />
        <MetricCard
          title="CURRENT RISK INDEX"
          value="82 / 100"
          subtitle="Active Evaluation Baseline"
          icon={ShieldAlert}
          variant="amber"
          badge="CURRENT"
        />
        <MetricCard
          title="PROJECTED POST-MITIGATION"
          value="45 / 100"
          subtitle="Following OR-Tools Portfolio"
          icon={TrendingDown}
          variant="emerald"
          badge="TARGET"
        />
        <MetricCard
          title="NET TRAJECTORY DELTA"
          value="-37 Pts"
          subtitle="45.1% Risk Remediation"
          icon={ShieldCheck}
          variant="cyan"
          badge="PROGRESS"
        />
      </div>

      {/* Historical Area Chart */}
      <div className="enterprise-card p-6 border-[#1C2042] space-y-3">
        <div className="flex items-center justify-between border-b border-[#1C2042] pb-3">
          <div className="flex items-center space-x-2">
            <History className="w-4 h-4 text-cyan-400" />
            <h2 className="text-xs font-bold uppercase tracking-wider text-slate-200 font-mono">
              6-Month Cyber Risk Index & Financial Loss Trend
            </h2>
          </div>
          <span className="text-[10px] font-mono text-cyan-300">
            Source: Enterprise Historical Logs
          </span>
        </div>

        <div className="h-72 w-full pt-3">
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart data={historyData}>
              <defs>
                <linearGradient id="riskGradient" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#06B6D4" stopOpacity={0.4}/>
                  <stop offset="95%" stopColor="#06B6D4" stopOpacity={0.0}/>
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="#1C2042" />
              <XAxis dataKey="month" stroke="#64748B" fontSize={11} tickLine={false} />
              <YAxis stroke="#64748B" fontSize={11} domain={[0, 100]} tickLine={false} />
              <Tooltip
                contentStyle={{ backgroundColor: '#0C0E1A', borderColor: '#2A2F5A', borderRadius: '8px', fontSize: '11px' }}
                formatter={(val: any) => [`${val} / 100`, 'Enterprise Risk Index']}
              />
              <Area 
                type="monotone" 
                dataKey="enterprise_risk_score" 
                stroke="#06B6D4" 
                strokeWidth={2.5} 
                fillOpacity={1} 
                fill="url(#riskGradient)" 
              />
            </AreaChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Milestone Events Timeline */}
      <div className="enterprise-card p-5 border-[#1C2042] space-y-4">
        <h2 className="text-xs font-bold uppercase tracking-wider text-slate-200 font-mono">
          Security Interventions & Campaign Milestones
        </h2>

        <div className="space-y-3 font-mono text-xs">
          {[
            { date: 'Apr 2025', title: 'Perimeter Exploit Surge', desc: 'Critical CVE-2024-21762 FortiOS SSL VPN vulnerability detected across gateway.', status: 'CRITICAL', color: 'text-rose-400' },
            { date: 'Jun 2025', title: 'MFA Rollout on Jump-Hosts', desc: 'Enforced FIDO2 multi-factor authentication on all payment tier administrator jump-hosts.', status: 'RESOLVED', color: 'text-emerald-400' },
            { date: 'Aug 2025', title: 'FIN7 Phishing Campaign Intercepted', desc: 'Wazuh SIEM detected credential harvesting attempt targeting corporate treasury users.', status: 'CONTAINED', color: 'text-amber-400' },
            { date: 'Sep 2025', title: 'SIH Final Optimization Run', desc: 'Google OR-Tools knapsack solver executed with ₹1.00 Crore budget constraint.', status: 'ACTIVE', color: 'text-cyan-400' }
          ].map((item, idx) => (
            <div key={idx} className="p-3 rounded-lg bg-[#0C0E1A] border border-[#1C2042] flex items-start justify-between gap-3">
              <div className="space-y-0.5">
                <div className="flex items-center space-x-2">
                  <span className="text-[10px] text-slate-500 font-bold">{item.date}</span>
                  <span className="text-slate-500">•</span>
                  <span className="font-bold text-white">{item.title}</span>
                </div>
                <p className="text-[11px] text-slate-400 font-sans">{item.desc}</p>
              </div>
              <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${item.color} bg-[#12152A] border border-[#2A2F5A]`}>
                {item.status}
              </span>
            </div>
          ))}
        </div>
      </div>

    </div>
  );
};

export default RiskHistoryPage;
